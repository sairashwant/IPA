package model.colorscheme;

/**
 * Represents different pixel formats.
 */
public abstract class AbstractPixel {

}
